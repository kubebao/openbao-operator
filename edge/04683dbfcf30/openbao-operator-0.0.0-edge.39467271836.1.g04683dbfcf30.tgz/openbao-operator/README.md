# OpenBao Operator edge chart

Evaluation build from commit 04683dbfcf30b6324c9480565b009893444c9a43. Chart version: 0.0.0-edge.39467271836.1.g04683dbfcf30.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
