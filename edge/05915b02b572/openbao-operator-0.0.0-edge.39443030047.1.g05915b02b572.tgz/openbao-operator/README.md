# OpenBao Operator edge chart

Evaluation build from commit 05915b02b57220871af601758a4636b55bc031f6. Chart version: 0.0.0-edge.39443030047.1.g05915b02b572.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
