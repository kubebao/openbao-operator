# OpenBao Operator edge chart

Evaluation build from commit 0d0aedb7d611e34f1ab447c3582a98f947e2cf72. Chart version: 0.0.0-edge.39978448530.1.g0d0aedb7d611.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
