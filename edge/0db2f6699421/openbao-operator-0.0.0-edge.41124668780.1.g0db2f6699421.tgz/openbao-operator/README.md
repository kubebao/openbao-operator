# OpenBao Operator edge chart

Evaluation build from commit 0db2f6699421a99cf8ecb4739a043ca33dab5dca. Chart version: 0.0.0-edge.41124668780.1.g0db2f6699421.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
