# OpenBao Operator edge chart

Evaluation build from commit 11a16603ef2a3ef454e5d9c309b4d1fe8b31e334. Chart version: 0.0.0-edge.43961968084.1.g11a16603ef2a.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
