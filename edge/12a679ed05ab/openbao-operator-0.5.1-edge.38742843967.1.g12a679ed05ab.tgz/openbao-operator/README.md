# OpenBao Operator edge chart

Evaluation build from commit 12a679ed05ab601ae1371372aaa02c00c2082baa. Chart version: 0.5.1-edge.38742843967.1.g12a679ed05ab.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
