# OpenBao Operator edge chart

Evaluation build from commit 1459f37f2f43d535120aacd83d3151672e7d02b1. Chart version: 0.5.1-edge.38618371854.1.g1459f37f2f43.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
