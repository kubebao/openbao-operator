# OpenBao Operator edge chart

Evaluation build from commit 1eacea5ccc0df19ded92fdd0bcf1347b94686864. Chart version: 0.0.0-edge.38986919986.1.g1eacea5ccc0d.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
