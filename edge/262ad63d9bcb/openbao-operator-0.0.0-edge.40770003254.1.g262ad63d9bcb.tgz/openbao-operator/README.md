# OpenBao Operator edge chart

Evaluation build from commit 262ad63d9bcb810363ebc4285aa34d6e1eb7c9ea. Chart version: 0.0.0-edge.40770003254.1.g262ad63d9bcb.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
