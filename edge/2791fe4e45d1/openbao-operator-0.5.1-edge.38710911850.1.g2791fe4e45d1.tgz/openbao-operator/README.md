# OpenBao Operator edge chart

Evaluation build from commit 2791fe4e45d1350cb092621598c910ba748950f2. Chart version: 0.5.1-edge.38710911850.1.g2791fe4e45d1.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
