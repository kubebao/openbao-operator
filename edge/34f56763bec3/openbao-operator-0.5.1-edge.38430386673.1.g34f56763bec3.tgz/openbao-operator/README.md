# OpenBao Operator edge chart

Evaluation build from commit 34f56763bec3354d9dbdd84b0591171bba907333. Chart version: 0.5.1-edge.38430386673.1.g34f56763bec3.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
