# OpenBao Operator edge chart

Evaluation build from commit 362bccea26e836ca3c107daf103f89d538118ef8. Chart version: 0.0.0-edge.38967914524.1.g362bccea26e8.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
