# OpenBao Operator edge chart

Evaluation build from commit 3abf96fd6c74a978182614c1f1416d40b5705589. Chart version: 0.5.1-edge.38366007284.1.g3abf96fd6c74.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
