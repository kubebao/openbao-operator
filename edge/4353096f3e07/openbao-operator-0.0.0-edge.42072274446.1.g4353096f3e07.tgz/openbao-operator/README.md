# OpenBao Operator edge chart

Evaluation build from commit 4353096f3e079fabdb279159e87989a568e257da. Chart version: 0.0.0-edge.42072274446.1.g4353096f3e07.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
