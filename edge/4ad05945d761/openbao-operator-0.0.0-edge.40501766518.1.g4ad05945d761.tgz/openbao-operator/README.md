# OpenBao Operator edge chart

Evaluation build from commit 4ad05945d761e26bf78f60527341fce1ccb1bd70. Chart version: 0.0.0-edge.40501766518.1.g4ad05945d761.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
