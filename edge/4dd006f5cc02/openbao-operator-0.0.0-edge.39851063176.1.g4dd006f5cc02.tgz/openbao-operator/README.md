# OpenBao Operator edge chart

Evaluation build from commit 4dd006f5cc02cb06c257ccc2ef3d5b8ecd3eef8e. Chart version: 0.0.0-edge.39851063176.1.g4dd006f5cc02.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
