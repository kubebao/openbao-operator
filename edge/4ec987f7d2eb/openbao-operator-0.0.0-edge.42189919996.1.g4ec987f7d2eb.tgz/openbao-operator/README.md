# OpenBao Operator edge chart

Evaluation build from commit 4ec987f7d2eb28aa062cfbd5f363907ef227023b. Chart version: 0.0.0-edge.42189919996.1.g4ec987f7d2eb.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
