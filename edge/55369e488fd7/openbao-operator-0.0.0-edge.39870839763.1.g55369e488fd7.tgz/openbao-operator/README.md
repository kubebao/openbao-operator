# OpenBao Operator edge chart

Evaluation build from commit 55369e488fd7c09375f8e6ea9d19f926652f0618. Chart version: 0.0.0-edge.39870839763.1.g55369e488fd7.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
