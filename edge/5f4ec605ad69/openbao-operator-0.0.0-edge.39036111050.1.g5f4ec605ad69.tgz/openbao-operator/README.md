# OpenBao Operator edge chart

Evaluation build from commit 5f4ec605ad69d8e2e66ad1e167faa2972fd95266. Chart version: 0.0.0-edge.39036111050.1.g5f4ec605ad69.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
