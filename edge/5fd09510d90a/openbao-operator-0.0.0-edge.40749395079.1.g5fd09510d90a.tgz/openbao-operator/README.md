# OpenBao Operator edge chart

Evaluation build from commit 5fd09510d90ae1954fb4db11cc4844b2a56340f4. Chart version: 0.0.0-edge.40749395079.1.g5fd09510d90a.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
