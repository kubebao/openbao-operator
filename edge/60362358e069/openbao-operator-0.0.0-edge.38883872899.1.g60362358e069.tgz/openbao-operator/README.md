# OpenBao Operator edge chart

Evaluation build from commit 60362358e069e68c436cb7ece4594c5a764167ca. Chart version: 0.0.0-edge.38883872899.1.g60362358e069.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
