# OpenBao Operator edge chart

Evaluation build from commit 6179a4a2eb9b33bf72e3a84e892f2af5316a2e21. Chart version: 0.0.0-edge.39882520451.1.g6179a4a2eb9b.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
