# OpenBao Operator edge chart

Evaluation build from commit 710dbd51fd3f79e906c20dd90f27d6361813facd. Chart version: 0.5.1-edge.38532143715.1.g710dbd51fd3f.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
