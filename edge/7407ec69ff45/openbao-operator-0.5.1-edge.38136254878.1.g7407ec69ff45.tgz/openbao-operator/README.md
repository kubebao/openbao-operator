# OpenBao Operator edge chart

Evaluation build from commit 7407ec69ff45af5b122ded855971ee6c4486a313. Chart version: 0.5.1-edge.38136254878.1.g7407ec69ff45.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
