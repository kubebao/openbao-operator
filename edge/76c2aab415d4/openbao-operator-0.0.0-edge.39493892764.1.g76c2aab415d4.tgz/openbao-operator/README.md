# OpenBao Operator edge chart

Evaluation build from commit 76c2aab415d44426bb4ffc1d6d3533bf3b381e07. Chart version: 0.0.0-edge.39493892764.1.g76c2aab415d4.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
