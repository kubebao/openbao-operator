# OpenBao Operator edge chart

Evaluation build from commit 8af6bce9b1cef72ea1eff1cc2a3ec00368cf0895. Chart version: 0.0.0-edge.39122571943.1.g8af6bce9b1ce.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
