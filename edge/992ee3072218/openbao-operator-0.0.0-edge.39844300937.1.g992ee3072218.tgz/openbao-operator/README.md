# OpenBao Operator edge chart

Evaluation build from commit 992ee30722187b4cdb4f665113c093156c15f87b. Chart version: 0.0.0-edge.39844300937.1.g992ee3072218.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
