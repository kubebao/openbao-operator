# OpenBao Operator edge chart

Evaluation build from commit 994936d6b15bfff8113afaa4266da7a5cbab059b. Chart version: 0.0.0-edge.44901540311.1.g994936d6b15b.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
