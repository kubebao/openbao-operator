# OpenBao Operator edge chart

Evaluation build from commit 9989ea6480cdb4e71b49c3249d8f64dc1b9839b7. Chart version: 0.5.1-edge.38799884756.1.g9989ea6480cd.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
