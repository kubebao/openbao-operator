# OpenBao Operator edge chart

Evaluation build from commit 9b92ff8092c8bdf3d80376bda334c1ef9094c418. Chart version: 0.0.0-edge.38982896409.1.g9b92ff8092c8.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
