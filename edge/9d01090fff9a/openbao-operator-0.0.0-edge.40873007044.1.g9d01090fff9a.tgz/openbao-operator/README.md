# OpenBao Operator edge chart

Evaluation build from commit 9d01090fff9af7b2455716ffbae60b3b916c77c2. Chart version: 0.0.0-edge.40873007044.1.g9d01090fff9a.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
