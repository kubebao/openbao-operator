# OpenBao Operator edge chart

Evaluation build from commit b9d52d836e1a874c55ea56cf21be3d78b9293c56. Chart version: 0.0.0-edge.44335540499.1.gb9d52d836e1a.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
