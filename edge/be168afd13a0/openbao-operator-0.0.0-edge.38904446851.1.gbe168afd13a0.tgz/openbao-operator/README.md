# OpenBao Operator edge chart

Evaluation build from commit be168afd13a0830f2b8f5d966593538c231a630b. Chart version: 0.0.0-edge.38904446851.1.gbe168afd13a0.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
