# OpenBao Operator edge chart

Evaluation build from commit c5d61dcc48ec053ff5d685aa30fe680b89edb215. Chart version: 0.0.0-edge.40709094434.1.gc5d61dcc48ec.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
