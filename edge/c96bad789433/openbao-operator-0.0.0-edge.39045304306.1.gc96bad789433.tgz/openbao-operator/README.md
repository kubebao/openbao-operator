# OpenBao Operator edge chart

Evaluation build from commit c96bad7894331b25e378dd05a6d38c8824b19e2a. Chart version: 0.0.0-edge.39045304306.1.gc96bad789433.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
