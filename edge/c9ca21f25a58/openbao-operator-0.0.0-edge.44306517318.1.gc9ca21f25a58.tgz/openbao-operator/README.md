# OpenBao Operator edge chart

Evaluation build from commit c9ca21f25a589ed28a86be8fe80e852553089877. Chart version: 0.0.0-edge.44306517318.1.gc9ca21f25a58.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
