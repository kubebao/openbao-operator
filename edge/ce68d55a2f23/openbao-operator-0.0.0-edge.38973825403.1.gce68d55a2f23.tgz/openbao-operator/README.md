# OpenBao Operator edge chart

Evaluation build from commit ce68d55a2f23e08cdc8962650ac203fca023f76a. Chart version: 0.0.0-edge.38973825403.1.gce68d55a2f23.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
