# OpenBao Operator edge chart

Evaluation build from commit d0f09fe844d1d9bc4019e1c91273227a056db945. Chart version: 0.0.0-edge.39519368760.1.gd0f09fe844d1.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
