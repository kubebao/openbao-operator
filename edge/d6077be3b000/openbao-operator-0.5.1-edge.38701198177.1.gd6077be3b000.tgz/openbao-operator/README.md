# OpenBao Operator edge chart

Evaluation build from commit d6077be3b000f099360b1a5018f60fcdeec9d690. Chart version: 0.5.1-edge.38701198177.1.gd6077be3b000.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
