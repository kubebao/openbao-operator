# OpenBao Operator edge chart

Evaluation build from commit dab15f3ece031ab399c5c1b59d624a82a502632d. Chart version: 0.0.0-edge.40882832763.1.gdab15f3ece03.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
