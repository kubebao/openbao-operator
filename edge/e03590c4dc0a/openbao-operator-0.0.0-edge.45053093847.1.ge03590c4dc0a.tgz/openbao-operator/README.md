# OpenBao Operator edge chart

Evaluation build from commit e03590c4dc0a8c9dacc53265f49865029b8d556b. Chart version: 0.0.0-edge.45053093847.1.ge03590c4dc0a.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
