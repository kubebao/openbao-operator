# OpenBao Operator edge chart

Evaluation build from commit e761cfa72cc55dc994589f1af525bb45cc4e7ad5. Chart version: 0.0.0-edge.40414809272.1.ge761cfa72cc5.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
