# OpenBao Operator edge chart

Evaluation build from commit e845ed4ddec4f5dd2a51dae4958d8208629dffd1. Chart version: 0.0.0-edge.39835094930.1.ge845ed4ddec4.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
