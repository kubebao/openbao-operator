# OpenBao Operator edge chart

Evaluation build from commit e881cfc8e7d6dde04e7ecfd2591157204f2d905d. Chart version: 0.0.0-edge.39673176430.1.ge881cfc8e7d6.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
