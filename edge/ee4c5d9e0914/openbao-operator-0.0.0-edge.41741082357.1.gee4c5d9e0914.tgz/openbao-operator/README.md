# OpenBao Operator edge chart

Evaluation build from commit ee4c5d9e0914535e5235c9f32ac5fea1184bc125. Chart version: 0.0.0-edge.41741082357.1.gee4c5d9e0914.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
