# OpenBao Operator edge chart

Evaluation build from commit f580d3ce0f8f3f7ecfab0b78b470dabb7d034e3f. Chart version: 0.0.0-edge.44417162978.1.gf580d3ce0f8f.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
