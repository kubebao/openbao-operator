# OpenBao Operator edge chart

Evaluation build from commit f77e21c438067c8d5dcba391735b24dd38233968. Chart version: 0.0.0-edge.40083639589.1.gf77e21c43806.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
