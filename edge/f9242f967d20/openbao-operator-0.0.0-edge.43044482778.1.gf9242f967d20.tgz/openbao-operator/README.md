# OpenBao Operator edge chart

Evaluation build from commit f9242f967d2012e22e652689a4bbc72fdd5e1a89. Chart version: 0.0.0-edge.43044482778.1.gf9242f967d20.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
