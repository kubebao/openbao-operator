# OpenBao Operator edge chart

Evaluation build from commit b8ad55a6262f6e704f71e131bbced3de56c6e347. Chart version: 0.0.0-edge.38943788443.1.gb8ad55a6262f.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
