# OpenBao Operator edge chart

Evaluation build from commit f30593bad0fb4b0487189b4be40eaa6ba46e58dc. Chart version: 0.0.0-edge.38949477324.1.gf30593bad0fb.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
