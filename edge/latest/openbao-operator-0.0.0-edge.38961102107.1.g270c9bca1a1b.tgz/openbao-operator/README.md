# OpenBao Operator edge chart

Evaluation build from commit 270c9bca1a1bec28cf4771e92032c2e430f88d33. Chart version: 0.0.0-edge.38961102107.1.g270c9bca1a1b.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
