# OpenBao Operator edge chart

Evaluation build from commit ec30d8ecaf2a6b39525bdb0848c3f1f6f1349259. Chart version: 0.0.0-edge.39033142096.1.gec30d8ecaf2a.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
