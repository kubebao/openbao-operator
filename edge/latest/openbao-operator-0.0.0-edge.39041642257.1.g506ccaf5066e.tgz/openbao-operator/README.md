# OpenBao Operator edge chart

Evaluation build from commit 506ccaf5066e9d443390ef7274d8eb24df70ba2f. Chart version: 0.0.0-edge.39041642257.1.g506ccaf5066e.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
