# OpenBao Operator edge chart

Evaluation build from commit b7483694634ec322d11562e913e26128edcc765a. Chart version: 0.0.0-edge.39056115352.1.gb7483694634e.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
