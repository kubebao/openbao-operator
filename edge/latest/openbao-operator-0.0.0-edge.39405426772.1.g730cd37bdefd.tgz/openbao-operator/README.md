# OpenBao Operator edge chart

Evaluation build from commit 730cd37bdefde327ba56c253488b8d87766eb9f5. Chart version: 0.0.0-edge.39405426772.1.g730cd37bdefd.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
