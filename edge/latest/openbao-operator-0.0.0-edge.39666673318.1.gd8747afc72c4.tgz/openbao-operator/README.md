# OpenBao Operator edge chart

Evaluation build from commit d8747afc72c42e2155a90f08390a002265408ecc. Chart version: 0.0.0-edge.39666673318.1.gd8747afc72c4.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
