# OpenBao Operator edge chart

Evaluation build from commit 49498ee6e8c73265fd280d918cdec56f13f4d219. Chart version: 0.0.0-edge.39699171467.1.g49498ee6e8c7.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
