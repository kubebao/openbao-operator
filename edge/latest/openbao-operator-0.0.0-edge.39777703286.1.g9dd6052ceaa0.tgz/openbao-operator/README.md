# OpenBao Operator edge chart

Evaluation build from commit 9dd6052ceaa03962b6bb8fbc709e8f9dc5d52993. Chart version: 0.0.0-edge.39777703286.1.g9dd6052ceaa0.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
