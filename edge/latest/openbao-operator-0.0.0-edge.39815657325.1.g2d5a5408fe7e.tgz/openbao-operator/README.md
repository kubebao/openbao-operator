# OpenBao Operator edge chart

Evaluation build from commit 2d5a5408fe7e02c42fbf39622b9e9bdcd9f41899. Chart version: 0.0.0-edge.39815657325.1.g2d5a5408fe7e.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
