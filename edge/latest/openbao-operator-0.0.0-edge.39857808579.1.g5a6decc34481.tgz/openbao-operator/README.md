# OpenBao Operator edge chart

Evaluation build from commit 5a6decc3448189f063ccedc071a646c093bf0461. Chart version: 0.0.0-edge.39857808579.1.g5a6decc34481.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
