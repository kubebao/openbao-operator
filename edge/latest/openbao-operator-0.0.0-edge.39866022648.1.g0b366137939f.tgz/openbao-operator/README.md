# OpenBao Operator edge chart

Evaluation build from commit 0b366137939f0c247521c85ff26c498166d451cc. Chart version: 0.0.0-edge.39866022648.1.g0b366137939f.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
