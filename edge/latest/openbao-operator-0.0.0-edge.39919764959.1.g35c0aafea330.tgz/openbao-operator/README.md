# OpenBao Operator edge chart

Evaluation build from commit 35c0aafea3302efdc0408b92fcf086e93f687b2d. Chart version: 0.0.0-edge.39919764959.1.g35c0aafea330.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
