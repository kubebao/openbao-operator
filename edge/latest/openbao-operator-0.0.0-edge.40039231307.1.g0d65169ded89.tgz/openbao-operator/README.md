# OpenBao Operator edge chart

Evaluation build from commit 0d65169ded89a089a44302f2e75d6bc3e6ee0572. Chart version: 0.0.0-edge.40039231307.1.g0d65169ded89.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
