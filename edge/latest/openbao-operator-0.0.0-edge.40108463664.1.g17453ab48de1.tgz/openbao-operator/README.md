# OpenBao Operator edge chart

Evaluation build from commit 17453ab48de175b9d00723a08e1af9c3e669b62b. Chart version: 0.0.0-edge.40108463664.1.g17453ab48de1.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
