# OpenBao Operator edge chart

Evaluation build from commit 1f52e3711fe44d40d92f77d9fd1fe3b930074f28. Chart version: 0.0.0-edge.40740856846.1.g1f52e3711fe4.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
