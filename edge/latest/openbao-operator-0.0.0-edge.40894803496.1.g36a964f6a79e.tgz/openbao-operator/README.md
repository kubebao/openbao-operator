# OpenBao Operator edge chart

Evaluation build from commit 36a964f6a79e606b3d3c84980b1fec23aeeab3ad. Chart version: 0.0.0-edge.40894803496.1.g36a964f6a79e.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
