# OpenBao Operator edge chart

Evaluation build from commit f96147f4966d60397218bc2923f57e6140d990a8. Chart version: 0.0.0-edge.41112313439.1.gf96147f4966d.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
