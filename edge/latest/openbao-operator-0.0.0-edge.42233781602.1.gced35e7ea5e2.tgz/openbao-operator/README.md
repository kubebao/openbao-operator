# OpenBao Operator edge chart

Evaluation build from commit ced35e7ea5e2a5ab0b95cd7adc25082a19d5146e. Chart version: 0.0.0-edge.42233781602.1.gced35e7ea5e2.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
