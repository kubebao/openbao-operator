# OpenBao Operator edge chart

Evaluation build from commit e5e8e4ba652b5c1a394fc436fdb425b47c73056f. Chart version: 0.0.0-edge.42349517158.1.ge5e8e4ba652b.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
