# OpenBao Operator edge chart

Evaluation build from commit 24965bdc52197944b29b37ebe41c6fe8c4281c8a. Chart version: 0.0.0-edge.42369056985.1.g24965bdc5219.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
