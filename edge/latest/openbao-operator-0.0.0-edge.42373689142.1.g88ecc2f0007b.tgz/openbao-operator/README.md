# OpenBao Operator edge chart

Evaluation build from commit 88ecc2f0007b6a6eafab59d901ed90dd239d39e8. Chart version: 0.0.0-edge.42373689142.1.g88ecc2f0007b.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
