# OpenBao Operator edge chart

Evaluation build from commit 587dd16386bc5a234520e22eec1bbedb904fa6dd. Chart version: 0.0.0-edge.43118921813.1.g587dd16386bc.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
