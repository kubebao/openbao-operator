# OpenBao Operator edge chart

Evaluation build from commit d98a6e0c6e65cccd8a14c9a411c25d28e842a1e1. Chart version: 0.0.0-edge.43210588129.1.gd98a6e0c6e65.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
