# OpenBao Operator edge chart

Evaluation build from commit 12e842aefad251e1c6eb82202536fa852444403e. Chart version: 0.0.0-edge.43299537438.1.g12e842aefad2.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
