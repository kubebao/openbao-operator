# OpenBao Operator edge chart

Evaluation build from commit 7b9bbf8b1a2aa3a62e2235607073df3e912643b5. Chart version: 0.0.0-edge.43427268827.1.g7b9bbf8b1a2a.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
