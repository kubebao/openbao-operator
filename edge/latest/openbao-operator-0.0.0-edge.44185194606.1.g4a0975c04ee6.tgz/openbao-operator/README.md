# OpenBao Operator edge chart

Evaluation build from commit 4a0975c04ee648d0a78e181e350dc42d40832d3f. Chart version: 0.0.0-edge.44185194606.1.g4a0975c04ee6.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
