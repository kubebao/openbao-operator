# OpenBao Operator edge chart

Evaluation build from commit 2da026a66a48645a56976eb6f25615e233b5d67f. Chart version: 0.0.0-edge.44747092412.1.g2da026a66a48.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
