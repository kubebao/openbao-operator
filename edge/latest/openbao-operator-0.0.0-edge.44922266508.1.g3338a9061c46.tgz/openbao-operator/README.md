# OpenBao Operator edge chart

Evaluation build from commit 3338a9061c46fd4a00f6b6becaf43327602bb372. Chart version: 0.0.0-edge.44922266508.1.g3338a9061c46.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
