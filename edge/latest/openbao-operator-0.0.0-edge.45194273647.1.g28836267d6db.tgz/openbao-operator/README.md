# OpenBao Operator edge chart

Evaluation build from commit 28836267d6db6d17501566823b500dfc773a19e4. Chart version: 0.0.0-edge.45194273647.1.g28836267d6db.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
