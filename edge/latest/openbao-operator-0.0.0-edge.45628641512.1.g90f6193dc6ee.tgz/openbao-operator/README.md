# OpenBao Operator edge chart

Evaluation build from commit 90f6193dc6eee12b281728d437a57cbb8ce287ea. Chart version: 0.0.0-edge.45628641512.1.g90f6193dc6ee.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
