# OpenBao Operator edge chart

Evaluation build from commit 3fba3271d69575f664853f617999e2e71c491f51. Chart version: 0.0.0-edge.45782028047.1.g3fba3271d695.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
