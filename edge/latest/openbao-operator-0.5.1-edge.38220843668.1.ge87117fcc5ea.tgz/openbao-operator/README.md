# OpenBao Operator edge chart

Evaluation build from commit e87117fcc5ea2b98849b155989b9a9ce0bfcade1. Chart version: 0.5.1-edge.38220843668.1.ge87117fcc5ea.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
