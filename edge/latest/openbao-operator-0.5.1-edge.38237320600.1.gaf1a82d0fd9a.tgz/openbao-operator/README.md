# OpenBao Operator edge chart

Evaluation build from commit af1a82d0fd9a4b5f2289656e5e567589d9ff50f1. Chart version: 0.5.1-edge.38237320600.1.gaf1a82d0fd9a.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
