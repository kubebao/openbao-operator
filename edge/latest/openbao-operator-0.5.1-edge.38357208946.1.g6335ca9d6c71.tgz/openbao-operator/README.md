# OpenBao Operator edge chart

Evaluation build from commit 6335ca9d6c71a17ac98cb23629512b6bd32d4e5b. Chart version: 0.5.1-edge.38357208946.1.g6335ca9d6c71.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
