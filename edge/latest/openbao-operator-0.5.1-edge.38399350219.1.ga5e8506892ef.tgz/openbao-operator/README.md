# OpenBao Operator edge chart

Evaluation build from commit a5e8506892efa87d1a86bc9ceb3a718910acf230. Chart version: 0.5.1-edge.38399350219.1.ga5e8506892ef.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
