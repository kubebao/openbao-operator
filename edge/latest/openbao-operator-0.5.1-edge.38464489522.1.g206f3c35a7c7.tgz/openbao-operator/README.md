# OpenBao Operator edge chart

Evaluation build from commit 206f3c35a7c7e1cf1bd2d04457dcd0edc26893dc. Chart version: 0.5.1-edge.38464489522.1.g206f3c35a7c7.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
