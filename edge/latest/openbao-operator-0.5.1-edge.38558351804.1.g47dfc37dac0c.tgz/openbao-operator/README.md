# OpenBao Operator edge chart

Evaluation build from commit 47dfc37dac0c99f63bbc40cddf3378f6635f4aec. Chart version: 0.5.1-edge.38558351804.1.g47dfc37dac0c.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
