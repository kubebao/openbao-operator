# OpenBao Operator edge chart

Evaluation build from commit 5048abdc560c838470f1315573bb9a579e4c44f5. Chart version: 0.5.1-edge.38645408841.1.g5048abdc560c.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
