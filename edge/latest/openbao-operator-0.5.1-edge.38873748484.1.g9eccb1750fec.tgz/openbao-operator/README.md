# OpenBao Operator edge chart

Evaluation build from commit 9eccb1750fec1c3bd53dd4dc2a3e6158054b7ea8. Chart version: 0.5.1-edge.38873748484.1.g9eccb1750fec.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
